import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';


void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,

    home: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          backgroundColor: Colors.tealAccent,
          leading: Icon(Icons.account_circle_rounded),
          title: Text('FA19-BCS-129'),
        ),
        backgroundColor: Colors.tealAccent,
        body: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextField(
                keyboardType: TextInputType.number,
                decoration: InputDecoration(

                    hintText: 'Enter number to ring '
                ),

              ),
              RaisedButton( onPressed:null,
                child: Text('click'),
              ),
              Text(''),

              getView(1 , Colors.blue),
              getView(2 , Colors.teal),
              getView(3 , Colors.orange),
              getView(4 , Colors.yellow),
              getView(5 , Colors.brown),
              getView(6 , Colors.blueAccent),
              getView(7 , Colors.red),
            ],
          ),
        )
    ),
  ));
}

Widget getView(int pos , Color color){
  return  Expanded(
    child: TextButton(
      style: ButtonStyle(
          backgroundColor: MaterialStateProperty.all(color)
      ),
      onPressed: (){
        playSound(pos);
      },
      child: Text("Click to hear"),
    ),
  );
}

void playSound(int pos) {
  final audioPlayer = AudioCache();
  audioPlayer.play('assets_note$pos.wav');
}